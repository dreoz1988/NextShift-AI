Proprietary License – Dwayne AI

© 2025 NextShift AI. All rights reserved.

This software and all associated content (including code, assets, voice, avatar modules, and escalation logic) is the exclusive property of NextShift AI and Andre Osborn. It is NOT open source and may not be:

- Reproduced
- Shared
- Reverse-engineered
- Licensed
- Disclosed
- Used in derivative works

Use is only permitted under signed NDA and Contributor License Agreement (CLA). Any unauthorized use is a breach of IP law and will be pursued to the fullest extent.

For legal inquiries or licensing requests, contact: legal@nextshift.ai
