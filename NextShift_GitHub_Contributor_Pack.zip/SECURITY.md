# 🔐 Security Policy – NextShift AI

## Reporting Vulnerabilities

If you discover a potential security issue in any NextShift AI repository (including Dwayne AI):

- **Do not open a public issue**
- Contact us directly at: **security@nextshift.ai**
- Include details such as:
  - Affected files or modules
  - Steps to reproduce
  - Potential impact and risk level

We take security seriously and will respond within 48 hours.

## Supported Versions

| Version         | Supported |
|------------------|-----------|
| main (production) | ✅ Yes     |
| dev (beta)        | ✅ Yes     |
| feature branches  | ⚠️ Reviewed as needed |

---

Thank you for helping keep the platform secure and trusted.
