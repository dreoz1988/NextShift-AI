# 🤝 Contributing to Dwayne AI (Private Repository)

Thank you for being a part of the confidential development of **Dwayne AI**, the multilingual, POS-integrated voice assistant powering NextShift AI.

This repository contains proprietary logic, confidential modules, and IP-protected systems. Contributing here requires strict adherence to legal and procedural guidelines.

---

## 🛡️ Access Rules

- This repository is **private and invitation-only**.
- Unauthorized access or redistribution is prohibited.
- You must have a signed NDA + CLA on file before contributing.

---

## 📝 Required Agreements

Before contributing code, you must:

1. Review and sign our [Contributor License Agreement (CLA) and Non-Disclosure Agreement (NDA)](./contracts/Dwayne_AI_NDA_CLA_Agreement.pdf)
2. Email the signed agreement to: **dreoz1988@gmail.com**
3. Include your **GitHub username** in the email
4. Wait for confirmation of whitelisting

> ❗ Pull Requests (PRs) from unverified users will be closed automatically.

---

## 🛠️ How to Contribute

1. **Clone this repository** (only after access granted)
2. Create a new branch for your work:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. Commit changes with context:
   ```bash
   git commit -m "Fix: Enhanced fallback logic for night coverage"
   ```
4. Push and submit a Pull Request (PR) into the `dev` branch

---

## ✅ Code Expectations

- Keep all proprietary logic within `core/`, `voice/`, or `integration/`
- Do not expose any protected config files or internal architecture
- Use encrypted variables for keys and voice tokens (never hardcode)

---

## 🔐 Security Reporting

If you identify a potential vulnerability:
- Do NOT open a public issue
- Report it directly to: **security@nextshift.ai**

---

## 🚫 Reminder

This code is proprietary and subject to legal protection. Any unauthorized use, copying, or disclosure is strictly prohibited and will be prosecuted.

---

Thank you for helping make Dwayne AI world-class and secure.  
— The NextShift AI Engineering Team
