# 🤝 Contributing to NextShift AI

Thank you for your interest in contributing to **NextShift AI**, the next-generation restaurant operations platform.

This guide outlines the process for contributing code, reporting bugs, and submitting feature requests — and includes our **Contributor License Agreement (CLA)** requirements.

---

## 🛠️ How to Contribute

1. **Fork this repository**
2. Create a new branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. Make your changes and commit:
   ```bash
   git commit -m "Add: Short description of your change"
   ```
4. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```
5. Submit a Pull Request (PR) into the `dev` branch

---

## ✅ Code Style & Standards

- Use consistent formatting (e.g. Black or Prettier)
- Follow naming conventions and docstring standards
- Write unit tests for all new features or modules
- Include meaningful commit messages

---

## 📝 Contributor License Agreement (CLA)

Before submitting code to this project, you must review and sign our [Contributor License Agreement (CLA) and Non-Disclosure Agreement (NDA)](./contracts/Dwayne_AI_NDA_CLA_Agreement.pdf).

By signing, you confirm that:
- Your contributions are your original work or you have rights to submit them.
- You grant NextShift AI a worldwide, irrevocable license to use, reproduce, modify, and distribute your contributions.
- You understand contributions may be used in both public and proprietary modules of the platform.

**To contribute:**
1. Sign the CLA and NDA PDF.
2. Email the signed copy to: **dreoz1988@gmail.com**
3. Include your **GitHub username** in the email.

> ⚠️ Note: Your pull requests (PRs) will not be accepted until your signed agreement is on file and your GitHub account is whitelisted.

---

## 🐛 Reporting Issues

Please use [GitHub Issues](https://github.com/YOUR_USERNAME/YOUR_REPO/issues) for:
- Bug reports
- Feature requests
- Documentation improvements

Be clear, respectful, and include reproduction steps or screenshots when possible.

---

## 🔐 Security

For vulnerabilities, please follow our [security disclosure process](./SECURITY.md) and email **security@nextshift.ai** directly.

---

Thank you for helping build the future of restaurant operations 🚀

— The NextShift AI Team
